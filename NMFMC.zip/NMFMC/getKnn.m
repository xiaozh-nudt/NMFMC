function [s]=getKnn (v,k)
  [~,b] = sort(v,'descend');
  [~,s1]=ind2sub(size(v),b); 
  s=s1(1,1:k);
end