clc;clear;
str = load(['.\1.miRNA-disease association\knowndiseasemirnainteraction.txt']);
[~,disease]=xlsread(['.\1.miRNA-disease association\disease name.xlsx']);
[~,miRNA]=xlsread(['.\1.miRNA-disease association\miRNA name.xlsx']);
% nd:the number of diseases
% nm:the number of miRNAs 
% pp:the number of known diseae-miRNA associations

nd = max(str(:,2));
nm = max(str(:,1));
[pp,~] = size(str);

% FS:the functional similarity between m(i) and m(j)
% FSP:Functional similarity weighting matrix
% SS:the semantic similarity between d(i) and d(j).
% SSP:semantic similarity weighting matrix
FS = load(['.\4.miNA functional simialrity\functional similarity matrix.txt']);
FSP = load(['.\4.miNA functional simialrity\Functional similarity weighting matrix.txt']);             
SS1 = load(['.\2.disease semantic similarity 1\disease semantic similarity matrix 1.txt']);
SS2 = load(['.\3.disease semantic similarity 2\disease semantic similarity matrix 2.txt']);
SS = (SS1+SS2)/2;
SSP = load(['.\2.disease semantic similarity 1\disease semantic similarity weighting matrix1.txt']);
% interaction: adajency matrix for the disease-miRNA association network
% interaction(i,j)=1 means miRNA j is related to disease i
interaction = zeros(nd,nm);
for i = 1:pp
    interaction(str(i,2),str(i,1)) = 1;
end
[kd,km] = gaussiansimilarity(interaction,nd,nm);                   %calculate gaussiansimilarity
[sd,sm] = integratedsimilarity(FS,FSP,SS,SSP,kd,km);     % Integrated similarity for diseases and miRNAs
[score,W,H,R]=NMFMC(sd,sm,interaction,100,1,0.1);  

%%=========================performance============================================================

pr_x=zeros(nd,nm);
pr_y=zeros(nd,nm);
PR_x=zeros(nd,nm);
PR_y=zeros(nd,nm);
auc_set=zeros(2,7);
row=1;
count=1;
 l1=0.01
 col=1;
 l2=1     
        for  a=1:nd   %ÿ�ּ�����һ�β���              
            %str
                index=find(str(:,2)~=a);
                outdata=zeros(length(index),2);
                outdata(:,1)=str(index);
                index3=find(str(:,2)<a);
                number3=length(index3);
                outdata(1:number3,2)=str(index3,2);
                index2=find(str(:,2)>a);
                number2=length(index2);
                outdata(number3+1:length(index),2)=str(index2,2)-1;   

             %FS
               nd1=max(outdata(:,2));        %�µļ�������
               [pp1,~] = size(outdata);
               test_interaction = zeros(1,495);
               interaction(a,:) =  test_interaction; 
               [kd1,km1] = gaussiansimilarity(interaction,nd,nm);
               [sd1,sm1] = integratedsimilarity(FS,FSP,SS,SSP,kd1,km1);  
               [score,~,~,~]=NMFMC(sd1,sm1,interaction,100,l1,l2);       %A=W,B=H

               SS1 = load(['.\2.disease semantic similarity 1\disease semantic similarity matrix 1.txt']);
               SS2 = load(['.\3.disease semantic similarity 2\disease semantic similarity matrix 2.txt']);
               SSP = load(['.\2.disease semantic similarity 1\disease semantic similarity weighting matrix1.txt']);
               SS=(SS1+SS2)/2;
               [x,y]= integratedsimilarity(FS,FSP,SS,SSP,kd1,km1);    %x=sd,y=sm
               score=score(a,:); %Ԥ��ֵ


            %% pr curve
               %  ��ʵֵ  
               ground=zeros(1,nm);
               index1=find(str(:,2)==a);
               ground(1,str(index1,1))=1;
               
              [Pre,Re,~,~]= precisionRecall( score,ground);   
              pr_x(a,:)=Re;
              pr_y(a,:)=Pre;

             %% roc ����
             [pre,INdex]=sort(score,'descend');
             ground1=ground(INdex);
             stack_x1 = cumsum(ground1 == 0)/sum(ground1 == 0);
             stack_y1 = cumsum(ground1 == 1)/sum(ground1== 1);
             auc_x(a,:)=stack_x1;
             auc_y(a,:)=stack_y1;

        end
        a_x=mean(auc_x);
        a_y=mean(auc_y);
        auc = sum((a_x(1,2:length(ground))-a_x(1,1:length(ground)-1)).*a_y(1,2:length(ground)));

        auc_set(row,col)=auc;
        col=col+1;
        pathname=[num2str(count),'_new','.mat'];
        save(pathname);
        count=count+1;
      
save param.mat

