function [score,W,H,R]=NMFMC(Sd,Sm,Y,r,l1,l2)
  [~,n]=size(Sd);
  [~,m]=size(Sm);
  W = abs(rand(n,r));
% norms = sqrt(sum(W.^2,1));
% norms = max(norms,1e-10);
% W= W./repmat(norms,n,1);   
  H = abs(rand(r,m));
% H = H/sum(sum(H));
  R=zeros(n,m);
  L=ones(n,m);
  k=1;
  Norm = 1;
  NormV = 0;
%ͼ����Ld,Lm
d_mat_new=getKnnGraph(Sd,10);       %Sd
m_mat_new=getKnnGraph(Sm,10);       %Sm
diag_m = diag(sum(m_mat_new,2));     %Dm
diag_d = diag(sum(d_mat_new,2));     %Dd
%�������
  while k<500
        W=W.*((Y+R)*H'+l1*d_mat_new*W*H*H'+l1*W*H*m_mat_new*H')./(W*H*H'+l1*diag_d*W*H*H'+l1*W*H*diag_m*H'); 
        H=H.*(W'*(Y+R)+l1*W'*d_mat_new*W*H+l1*W'*W*H*m_mat_new)./(W'*W*H+l1*W'*diag_d*W*H+l1*W'*W*H*diag_m);
        R=-1.*(L-Y).*(Y-W*H)./((L-Y).*(L-Y)+l2*L);
        obj(k) = norm(Y-W*H+(L-Y).*R) + norm(R,1) + trace((W*H)'*(diag_d-d_mat_new)*(W*H))...
            + trace((W*H)*(diag_m-m_mat_new)*(W*H)');
        obj(k)
        plot(obj)
        k=k+1;
  end
  score = W*H;
  function [U, V] = NormalizeUV(U, V, NormV, Norm)
    nSmp = size(V,1);
    mFea = size(U,1);
    if Norm == 2
        if NormV
            norms = sqrt(sum(V.^2,1));
            norms = max(norms,1e-10);
            V = V./repmat(norms,nSmp,1);
            U = U.*repmat(norms,mFea,1);
        else
            norms = sqrt(sum(U.^2,1));
            norms = max(norms,1e-10);
            U = U./repmat(norms,mFea,1);
            V = V.*repmat(norms,nSmp,1);
        end
    else
        if NormV
            norms = sum(abs(V),1);
            norms = max(norms,1e-10);
            V = V./repmat(norms,nSmp,1);
            U = U.*repmat(norms,mFea,1);
        else
            norms = sum(abs(U),1);
            %norms = max(norms,1e-10);
            U = U./repmat(norms,mFea,1);
            V = V.*repmat(norms,nSmp,1);
        end
    end
 